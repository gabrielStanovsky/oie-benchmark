This folder will hold the Open-IE benchmark, after running the conversion from QA-SRL (see instructions [here](../README.md)).

Open IE Format
--------------
Each line represents a single Open IE extraction, in a tab separated format:
```
SENTENCE	PREDICATE	ARG1	ARG2	....
```